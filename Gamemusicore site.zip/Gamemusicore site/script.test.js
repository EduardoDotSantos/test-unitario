
const { validatePassword, feedback} = require('./script.js');

it('User Valid', () => {
    expect(validatePassword('aA2')).toBe(true)
})
it('User Invalid', () => {
    expect(validatePassword('a2')).toBe(false)
})

const { confirmPassword } = require('./script.js');

it('cpassword true', () => {
    expect(confirmPassword('senha', 'senha')).toBe(true);
})

const { ageblock } = require('./script.js');
it('age true', ()=> {
    expect(ageblock(18)).toBe(true);
    
})
it('age false', () => {
    expect(ageblock(15)).toBe(false);
})
describe('feedback do formulario', () => {
    test('mensagem para menor de 18', ()=> {
        const resultado = feedback(17, 'Senha123', 'Senha123')
        expect(resultado).toBe("Você não tem a idade necessária para acessar o site");
    });
    test('mensagem para senha sem os requisitos', ()=> {
        const resultado = feedback(18, 'senha123', 'senha123')
        expect(resultado).toBe("A senha não atende aos requisitos");
    });
    test('mensagem para senhas diferentes', ()=> {
        const resultado = feedback(18, 'Senha123', 'Senha12')
        expect(resultado).toBe("As senhas não coincidem");
    })
})
